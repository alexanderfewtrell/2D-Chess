## Overview
Welcome to the Chess Game! This game is created using Unity and C# programming language. It provides a virtual chessboard where players can enjoy the classic game of chess against another player.

## Features
- Play against a friend: Enjoy a multiplayer experience by playing against a friend on the same device.
- Intuitive User Interface: The game provides a user-friendly interface with drag-and-drop functionality for moving chess pieces.
- Highlighting: The game highlights valid moves for each selected chess piece, making it easier for players to plan their strategies.

## Installation
1. No instilation required. Just double click the excecutable file.

## Controls
- Mouse: Use the mouse to interact with the game interface, including selecting and moving chess pieces.

## System Requirements
- Operating System: Windows 7 or later
- Processor: Dual-core processor or higher recomended
- Memory: 2 GB RAM or higher recomended
- Graphics: DirectX 11 compatible graphics card or higher

## License
This Chess Game is distributed under the [MIT License](https://opensource.org/licenses/MIT). Feel free to modify and distribute the game according to the terms of the license.

## Acknowledgements
- Unity Technologies for providing the Unity game development platform.
- The open-source community for their contributions to the development of Unity and C# libraries.

## Source Code
The Source code is available on GitHub at https://github.com/alexanderfewtrell/2D-Chess

## Feedback and Support
I value your feedback and suggestions to improve the Chess Game. If you have any questions, feedback, or need support, please contact me at alexanderfewtrell@tncit.co.uk.

Enjoy playing the Chess Game!